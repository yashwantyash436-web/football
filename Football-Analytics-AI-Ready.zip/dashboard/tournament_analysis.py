# Tournament analysis page
